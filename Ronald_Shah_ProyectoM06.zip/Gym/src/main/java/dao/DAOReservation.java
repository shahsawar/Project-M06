package dao;

import clases.Reservation;

/**
 * @author Shah, Ronald
 */
public interface DAOReservation extends DAO<Reservation, Integer> {

}
